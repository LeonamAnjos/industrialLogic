package com.industriallogic.bonus;

public class BonusCalculator {

	public double individualBonus(int sales, int quota, double commission, double tax) {
		if (!hasBonus(sales, quota))
			return 0;
		
		return calcDiff(sales, quota) * calcCommission(commission) * getTax(tax);
	}

	public double teamBonus(int sales, int quota, double commission, int numberOfTeamMembers) {
		if (!hasBonus(sales, quota))
			return 0;
		
		if (!isNumberOfTeamMembersValid(numberOfTeamMembers))
			return 0;
		
		return calcDiff(sales, quota) * calcCommission(commission) / numberOfTeamMembers;
	}

	private boolean isNumberOfTeamMembersValid(int numberOfTeamMembers) {
		return numberOfTeamMembers > 0;
	}
	
	private boolean hasBonus(int sales, int quota) {
		return sales > quota;
	}

	private double calcCommission(double commission) {
		return commission / 100;
	}

	private double getTax(double tax) {
		return 1 - (tax / 100);
	}

	private int calcDiff(int sales, int quota) {
		return sales - quota;
	}
}

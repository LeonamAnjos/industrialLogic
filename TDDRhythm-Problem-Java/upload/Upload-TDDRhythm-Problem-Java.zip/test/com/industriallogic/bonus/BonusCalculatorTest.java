// ***************************************************************************
// Copyright (c) 2014, Industrial Logic, Inc., All Rights Reserved.
//
// This code is the exclusive property of Industrial Logic, Inc. It may ONLY be
// used by students during Industrial Logic's workshops or by individuals
// who are being coached by Industrial Logic on a project.
//
// This code may NOT be copied or used for any other purpose without the prior
// written consent of Industrial Logic, Inc.
// ****************************************************************************

package com.industriallogic.bonus;

import junit.framework.Assert;

import org.junit.Test;


public class BonusCalculatorTest {
    // you may want to use "precision" (below) in your asserts...
    // private static final double precision = 0.001;
	
	@Test
	public void testIndividualBonusWhenSalesAreEqualOrSmallerThanQuota() {
		Assert.assertEquals(0.0, new BonusCalculator().individualBonus(10, 11, 10.0, 10));
		Assert.assertEquals(0.0, new BonusCalculator().individualBonus(11, 11, 10.0, 10));
	}
	
	@Test
	public void testIndividualBonusWhenSalesAreBiggerThanQuotaAndCommissionIsZero() {
		Assert.assertEquals(0.0, new BonusCalculator().individualBonus(12, 11, 0, 10));
	}
	
	@Test
	public void testIndividualBonusWhenSalesAreBiggerThanQuotaAndTaxIsZero() {
		Assert.assertEquals(0.10, new BonusCalculator().individualBonus(12, 11, 10, 0));
		Assert.assertEquals(0.40, new BonusCalculator().individualBonus(13, 11, 20, 0));
	}
	
	@Test
	public void testIndividualBonusWhenSalesAreBiggerThanQuota() {
		Assert.assertEquals(0.90, new BonusCalculator().individualBonus(120, 110, 10, 10));
		Assert.assertEquals(3.60, new BonusCalculator().individualBonus(130, 110, 20, 10));
		Assert.assertEquals(3.80, new BonusCalculator().individualBonus(130, 110, 20, 5));
	}
	
	@Test
	public void testTeamBonusWhenSalesGroupAreEqualOrSmallerThanQuota() {
		Assert.assertEquals(0.0, new BonusCalculator().teamBonus(10, 11, 10.0, 10));
		Assert.assertEquals(0.0, new BonusCalculator().teamBonus(11, 11, 10.0, 10));
	}
	
	@Test
	public void testTeamBonusWhenSalesGroupAreBiggerThanQuota() {
		Assert.assertEquals(0.0, new BonusCalculator().teamBonus(12, 11, 0, 10));
	}
	
	@Test
	public void testTeamBonusWhenSalesAreBiggerThanQuotaAndTeamMembersIsInvalid() {
		Assert.assertEquals(0.0, new BonusCalculator().teamBonus(12, 11, 10, -1));
		Assert.assertEquals(0.0, new BonusCalculator().teamBonus(12, 11, 10, 0));
		Assert.assertEquals(0.0, new BonusCalculator().teamBonus(13, 11, 20, 0));
	}
	
	@Test
	public void testTeamBonusWhenSalesAreBiggerThanQuotaAndTeamHasOnlyOneMember() {
		Assert.assertEquals(1.0, new BonusCalculator().teamBonus(120, 110, 10, 1));
		Assert.assertEquals(4.0, new BonusCalculator().teamBonus(130, 110, 20, 1));
	}
	
	@Test
	public void testTeamBonusWhenSalesAreBiggerThanQuotaAndTeamHasMoreThanOneMember() {
		Assert.assertEquals(0.5, new BonusCalculator().teamBonus(120, 110, 10, 2));
		Assert.assertEquals(1.0, new BonusCalculator().teamBonus(130, 110, 20, 4));
	}
}
	
